using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.MediaTypes
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public MediaType MediaType { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            MediaType = await _context.MediaType
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.MediaTypeId == id);
        
            if ( MediaType == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            MediaType = await _context.MediaType
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.MediaTypeId == id);
        
            if ( MediaType!= null )
            {
                _context.MediaType.Remove(MediaType);
                await _context.SaveChangesAsync();
            }
        Message = "MediaType deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


