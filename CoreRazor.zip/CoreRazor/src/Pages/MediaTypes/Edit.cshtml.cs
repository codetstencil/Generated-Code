using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.MediaTypes
{
    public class EditModel : MediaTypeLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public MediaType MediaType { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            MediaType = await _context.MediaType.FirstOrDefaultAsync(m => m.MediaTypeId == id);
        
            if (MediaType == null)
                return NotFound();
        
            return Page();
        }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();
        
            _context.Attach(MediaType).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MediaTypeExists(MediaType.MediaTypeId))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToPage("./Index");
        }
        private bool MediaTypeExists(int? id)
        {
            return _context.MediaType.Any(e => e.MediaTypeId == id);
        }
        

    }
}

