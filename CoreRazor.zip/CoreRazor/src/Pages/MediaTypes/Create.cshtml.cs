using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.MediaTypes
{
    public class CreateModel : MediaTypeLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            return Page();
        }
        
        [BindProperty]
        public MediaType MediaType { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            _context.MediaType.Add(MediaType);
            await _context.SaveChangesAsync();
        Message = "MediaType created successfully.";
            return RedirectToPage("./Index");
        }

    }
}

