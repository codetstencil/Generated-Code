using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Customers
{
    public class CreateModel : CustomerLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateEmployeeLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public Customer Customer { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyCustomer = new Customer();
        
            if (await TryUpdateModelAsync<Customer>(
                 emptyCustomer,
                 "customer",
                 s => s.FirstName,s => s.LastName,s => s.Company,s => s.Address,s => s.City,s => s.State,s => s.Country,s => s.PostalCode,s => s.Phone,s => s.Fax,s => s.Email,s => s.SupportRepId))
            {
                _context.Customer.Add(emptyCustomer);
                await _context.SaveChangesAsync();
        Message = "Customer created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateEmployeeLookup(_context, emptyCustomer.SupportRepId);
            return Page();
        }

    }
}

