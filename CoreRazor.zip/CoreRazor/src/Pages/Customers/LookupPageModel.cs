using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Customers
{
    public class CustomerLookupPageModel : PageModel
    {
        public SelectList EmployeeSelectList { get; set; }
        
        public  void PopulateEmployeeLookup(CoreRazorContext context, object selectedEmployee = null)
        {
            var employeesQuery = from q in context.Employee orderby q.LastName select q;
            EmployeeSelectList = new SelectList(employeesQuery.AsNoTracking(), "EmployeeId", "LastName", selectedEmployee);
        }
        

    }
}
