using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Customers
{
    public class EditModel : CustomerLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Customer Customer { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Customer = await _context.Customer
                .Include(c =>c.Employee)
                .FirstOrDefaultAsync(m => m.CustomerId == id);
        
            if (Customer == null)
                return NotFound();
        
            // Select current SupportRepId.
            PopulateEmployeeLookup(_context,Customer.CustomerId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var customerToUpdate = await _context.Customer.FindAsync(id);
        
            if (await TryUpdateModelAsync<Customer>(
                 customerToUpdate,
                 "customer",
                   s => s.FirstName,s => s.LastName,s => s.Company,s => s.Address,s => s.City,s => s.State,s => s.Country,s => s.PostalCode,s => s.Phone,s => s.Fax,s => s.Email,s => s.SupportRepId))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select SupportRepId if TryUpdateModeAsync fails.
            PopulateEmployeeLookup(_context,customerToUpdate.SupportRepId);
            return Page();
        }
        

    }
}

