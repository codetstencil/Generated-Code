using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Customers
{
    public class IndexModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        [TempData]
        public string Message { get; set; }
        
        public IndexModel(CoreRazorContext context) => _context = context;
        
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public string FirstNameSort { get; set; }
        public string CitySort { get; set; }
        public PaginatedList<Customer> Customer { get; set; }
        
        public async Task OnGetAsync(string sortOrder, string currentFilter, string searchString, int? pageIndex)
        {
            CurrentSort = sortOrder;
            FirstNameSort = sortOrder == "firstname_asc" ? "firstname_desc" : "firstname_asc";
            CitySort = sortOrder == "city_asc" ? "city_desc" : "city_asc";
        
            var customerIq = from s in _context.Customer select s;
            CurrentFilter = searchString;
            if (!String.IsNullOrEmpty(searchString))
            {
                customerIq = customerIq.Where(s=>s.FirstName.Contains(searchString));
            }
            
        
            switch (sortOrder)
            {
                case "firstname_asc":
                    customerIq = customerIq.OrderBy(s => s.FirstName);
                    break;
                case "firstname_desc":
                    customerIq = customerIq.OrderByDescending(s => s.FirstName);
                    break;
                case "city_asc":
                    customerIq = customerIq.OrderBy(s => s.City);
                    break;
                case "city_desc":
                    customerIq = customerIq.OrderByDescending(s => s.City);
                    break;
            }
            const int pageSize = 6;
            Customer = await PaginatedList<Customer>.CreateAsync(customerIq
               .AsNoTracking()
               .Include(c => c.Employee)
               , pageIndex ?? 1, pageSize);
        }
    }
}


