using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public Track Track { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Track = await _context.Track
              .AsNoTracking().Include(s => s.Album).Include(s => s.MediaType).Include(s => s.Genre)
              .FirstOrDefaultAsync(m => m.TrackId == id);
        
            if ( Track == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Track = await _context.Track
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.TrackId == id);
        
            if ( Track!= null )
            {
                _context.Track.Remove(Track);
                await _context.SaveChangesAsync();
            }
        Message = "Track deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


