using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class EditModel : TrackLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Track Track { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Track = await _context.Track
                .Include(c =>c.Album).Include(c =>c.MediaType).Include(c =>c.Genre)
                .FirstOrDefaultAsync(m => m.TrackId == id);
        
            if (Track == null)
                return NotFound();
        
            // Select current AlbumId.
            PopulateAlbumLookup(_context,Track.TrackId);
            // Select current MediaTypeId.
            PopulateMediaTypeLookup(_context,Track.TrackId);
            // Select current GenreId.
            PopulateGenreLookup(_context,Track.TrackId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var trackToUpdate = await _context.Track.FindAsync(id);
        
            if (await TryUpdateModelAsync<Track>(
                 trackToUpdate,
                 "track",
                   s => s.Name,s => s.AlbumId,s => s.MediaTypeId,s => s.GenreId,s => s.Composer,s => s.Milliseconds,s => s.Bytes,s => s.UnitPrice))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select AlbumId if TryUpdateModeAsync fails.
            PopulateAlbumLookup(_context,trackToUpdate.AlbumId);
            // Select MediaTypeId if TryUpdateModeAsync fails.
            PopulateMediaTypeLookup(_context,trackToUpdate.MediaTypeId);
            // Select GenreId if TryUpdateModeAsync fails.
            PopulateGenreLookup(_context,trackToUpdate.GenreId);
            return Page();
        }
        

    }
}

