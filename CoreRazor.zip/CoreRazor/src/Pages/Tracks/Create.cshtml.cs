using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class CreateModel : TrackLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateAlbumLookup(_context);
            PopulateMediaTypeLookup(_context);
            PopulateGenreLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public Track Track { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyTrack = new Track();
        
            if (await TryUpdateModelAsync<Track>(
                 emptyTrack,
                 "track",
                 s => s.Name,s => s.AlbumId,s => s.MediaTypeId,s => s.GenreId,s => s.Composer,s => s.Milliseconds,s => s.Bytes,s => s.UnitPrice))
            {
                _context.Track.Add(emptyTrack);
                await _context.SaveChangesAsync();
        Message = "Track created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateAlbumLookup(_context, emptyTrack.AlbumId);
            PopulateMediaTypeLookup(_context, emptyTrack.MediaTypeId);
            PopulateGenreLookup(_context, emptyTrack.GenreId);
            return Page();
        }

    }
}

