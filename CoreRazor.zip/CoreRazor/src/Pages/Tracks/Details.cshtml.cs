using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class DetailsModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DetailsModel(CoreRazorContext context) => _context = context;
        
        public Track Track { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Track = await _context.Track
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.TrackId == id);
        
            if ( Track == null )
                return NotFound();
            return Page();
        }

    }

}



