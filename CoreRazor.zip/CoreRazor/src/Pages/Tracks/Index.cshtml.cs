using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class IndexModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        [TempData]
        public string Message { get; set; }
        
        public IndexModel(CoreRazorContext context) => _context = context;
        
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public PaginatedList<Track> Track { get; set; }
        
        public async Task OnGetAsync(string sortOrder, string currentFilter, string searchString, int? pageIndex)
        {
            var trackIq = from s in _context.Track select s;
            const int pageSize = 6;
            Track = await PaginatedList<Track>.CreateAsync(trackIq
               .AsNoTracking()
               .Include(c => c.Album)
               .Include(c => c.MediaType)
               .Include(c => c.Genre)
               , pageIndex ?? 1, pageSize);
        }
    }
}


