using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Tracks
{
    public class TrackLookupPageModel : PageModel
    {
        public SelectList AlbumSelectList { get; set; }
        
        public  void PopulateAlbumLookup(CoreRazorContext context, object selectedAlbum = null)
        {
            var albumsQuery = from q in context.Album orderby q.Title select q;
            AlbumSelectList = new SelectList(albumsQuery.AsNoTracking(), "AlbumId", "Title", selectedAlbum);
        }
        
        public SelectList MediaTypeSelectList { get; set; }
        
        public  void PopulateMediaTypeLookup(CoreRazorContext context, object selectedMediaType = null)
        {
            var mediatypesQuery = from q in context.MediaType orderby q.Name select q;
            MediaTypeSelectList = new SelectList(mediatypesQuery.AsNoTracking(), "MediaTypeId", "Name", selectedMediaType);
        }
        
        public SelectList GenreSelectList { get; set; }
        
        public  void PopulateGenreLookup(CoreRazorContext context, object selectedGenre = null)
        {
            var genresQuery = from q in context.Genre orderby q.Name select q;
            GenreSelectList = new SelectList(genresQuery.AsNoTracking(), "GenreId", "Name", selectedGenre);
        }
        

    }
}
