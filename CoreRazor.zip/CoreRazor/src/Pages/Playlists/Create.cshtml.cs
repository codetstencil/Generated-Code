using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Playlists
{
    public class CreateModel : PlaylistLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            return Page();
        }
        
        [BindProperty]
        public Playlist Playlist { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            _context.Playlist.Add(Playlist);
            await _context.SaveChangesAsync();
        Message = "Playlist created successfully.";
            return RedirectToPage("./Index");
        }

    }
}

