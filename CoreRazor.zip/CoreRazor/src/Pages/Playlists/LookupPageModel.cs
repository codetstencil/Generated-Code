using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Playlists
{
    public class PlaylistLookupPageModel : PageModel
    {
        // Add your code here if you are creating lookup manually.

    }
}
