using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Playlists
{
    public class EditModel : PlaylistLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Playlist Playlist { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Playlist = await _context.Playlist.FirstOrDefaultAsync(m => m.PlaylistId == id);
        
            if (Playlist == null)
                return NotFound();
        
            return Page();
        }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();
        
            _context.Attach(Playlist).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlaylistExists(Playlist.PlaylistId))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToPage("./Index");
        }
        private bool PlaylistExists(int? id)
        {
            return _context.Playlist.Any(e => e.PlaylistId == id);
        }
        

    }
}

