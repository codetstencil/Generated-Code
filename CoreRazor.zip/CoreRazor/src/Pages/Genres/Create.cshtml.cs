using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Genres
{
    public class CreateModel : GenreLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            return Page();
        }
        
        [BindProperty]
        public Genre Genre { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            _context.Genre.Add(Genre);
            await _context.SaveChangesAsync();
        Message = "Genre created successfully.";
            return RedirectToPage("./Index");
        }

    }
}

