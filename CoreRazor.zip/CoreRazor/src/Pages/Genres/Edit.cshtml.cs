using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Genres
{
    public class EditModel : GenreLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Genre Genre { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Genre = await _context.Genre.FirstOrDefaultAsync(m => m.GenreId == id);
        
            if (Genre == null)
                return NotFound();
        
            return Page();
        }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();
        
            _context.Attach(Genre).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!GenreExists(Genre.GenreId))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToPage("./Index");
        }
        private bool GenreExists(int? id)
        {
            return _context.Genre.Any(e => e.GenreId == id);
        }
        

    }
}

