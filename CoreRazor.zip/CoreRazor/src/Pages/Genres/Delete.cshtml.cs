using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Genres
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public Genre Genre { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Genre = await _context.Genre
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.GenreId == id);
        
            if ( Genre == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Genre = await _context.Genre
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.GenreId == id);
        
            if ( Genre!= null )
            {
                _context.Genre.Remove(Genre);
                await _context.SaveChangesAsync();
            }
        Message = "Genre deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


