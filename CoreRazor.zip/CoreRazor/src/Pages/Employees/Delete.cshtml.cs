using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Employees
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public Employee Employee { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Employee = await _context.Employee
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.EmployeeId == id);
        
            if ( Employee == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Employee = await _context.Employee
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.EmployeeId == id);
        
            if ( Employee!= null )
            {
                _context.Employee.Remove(Employee);
                await _context.SaveChangesAsync();
            }
        Message = "Employee deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


