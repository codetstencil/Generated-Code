using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Employees
{
    public class EditModel : EmployeeLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Employee Employee { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Employee = await _context.Employee
                
                .FirstOrDefaultAsync(m => m.EmployeeId == id);
        
            if (Employee == null)
                return NotFound();
        
            // Select current ReportsTo.
            PopulateEmployeeLookup(_context,Employee.EmployeeId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var employeeToUpdate = await _context.Employee.FindAsync(id);
        
            if (await TryUpdateModelAsync<Employee>(
                 employeeToUpdate,
                 "employee",
                   s => s.LastName,s => s.FirstName,s => s.Title,s => s.ReportsTo,s => s.BirthDate,s => s.HireDate,s => s.Address,s => s.City,s => s.State,s => s.Country,s => s.PostalCode,s => s.Phone,s => s.Fax,s => s.Email))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select ReportsTo if TryUpdateModeAsync fails.
            PopulateEmployeeLookup(_context,employeeToUpdate.ReportsTo);
            return Page();
        }
        

    }
}

