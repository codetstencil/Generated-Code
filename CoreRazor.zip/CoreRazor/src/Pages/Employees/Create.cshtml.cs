using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Employees
{
    public class CreateModel : EmployeeLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateEmployeeLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public Employee Employee { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyEmployee = new Employee();
        
            if (await TryUpdateModelAsync<Employee>(
                 emptyEmployee,
                 "employee",
                 s => s.LastName,s => s.FirstName,s => s.Title,s => s.ReportsTo,s => s.BirthDate,s => s.HireDate,s => s.Address,s => s.City,s => s.State,s => s.Country,s => s.PostalCode,s => s.Phone,s => s.Fax,s => s.Email))
            {
                _context.Employee.Add(emptyEmployee);
                await _context.SaveChangesAsync();
        Message = "Employee created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateEmployeeLookup(_context, emptyEmployee.ReportsTo);
            return Page();
        }

    }
}

