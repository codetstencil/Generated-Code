using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Employees
{
    public class DetailsModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DetailsModel(CoreRazorContext context) => _context = context;
        
        public Employee Employee { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Employee = await _context.Employee
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.EmployeeId == id);
        
            if ( Employee == null )
                return NotFound();
            return Page();
        }

    }

}



