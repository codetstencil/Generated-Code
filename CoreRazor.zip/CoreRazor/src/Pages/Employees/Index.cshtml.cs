using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Employees
{
    public class IndexModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        [TempData]
        public string Message { get; set; }
        
        public IndexModel(CoreRazorContext context) => _context = context;
        
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public PaginatedList<Employee> Employee { get; set; }
        
        public async Task OnGetAsync(string sortOrder, string currentFilter, string searchString, int? pageIndex)
        {
            var employeeIq = from s in _context.Employee select s;
            const int pageSize = 6;
            Employee = await PaginatedList<Employee>.CreateAsync(employeeIq
               .AsNoTracking()
               , pageIndex ?? 1, pageSize);
        }
    }
}


