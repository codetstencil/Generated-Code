using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Invoices
{
    public class DetailsModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DetailsModel(CoreRazorContext context) => _context = context;
        
        public Invoice Invoice { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Invoice = await _context.Invoice
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.InvoiceId == id);
        
            if ( Invoice == null )
                return NotFound();
            return Page();
        }

    }

}



