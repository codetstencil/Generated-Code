using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Invoices
{
    public class InvoiceLookupPageModel : PageModel
    {
        public SelectList CustomerSelectList { get; set; }
        
        public  void PopulateCustomerLookup(CoreRazorContext context, object selectedCustomer = null)
        {
            var customersQuery = from q in context.Customer orderby q.FirstName select q;
            CustomerSelectList = new SelectList(customersQuery.AsNoTracking(), "CustomerId", "FirstName", selectedCustomer);
        }
        

    }
}
