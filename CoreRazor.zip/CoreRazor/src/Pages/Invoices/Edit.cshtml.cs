using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Invoices
{
    public class EditModel : InvoiceLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Invoice Invoice { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Invoice = await _context.Invoice
                .Include(c =>c.Customer)
                .FirstOrDefaultAsync(m => m.InvoiceId == id);
        
            if (Invoice == null)
                return NotFound();
        
            // Select current CustomerId.
            PopulateCustomerLookup(_context,Invoice.InvoiceId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var invoiceToUpdate = await _context.Invoice.FindAsync(id);
        
            if (await TryUpdateModelAsync<Invoice>(
                 invoiceToUpdate,
                 "invoice",
                   s => s.CustomerId,s => s.InvoiceDate,s => s.BillingAddress,s => s.BillingCity,s => s.BillingState,s => s.BillingCountry,s => s.BillingPostalCode,s => s.Total))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select CustomerId if TryUpdateModeAsync fails.
            PopulateCustomerLookup(_context,invoiceToUpdate.CustomerId);
            return Page();
        }
        

    }
}

