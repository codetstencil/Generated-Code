using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Invoices
{
    public class CreateModel : InvoiceLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateCustomerLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public Invoice Invoice { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyInvoice = new Invoice();
        
            if (await TryUpdateModelAsync<Invoice>(
                 emptyInvoice,
                 "invoice",
                 s => s.CustomerId,s => s.InvoiceDate,s => s.BillingAddress,s => s.BillingCity,s => s.BillingState,s => s.BillingCountry,s => s.BillingPostalCode,s => s.Total))
            {
                _context.Invoice.Add(emptyInvoice);
                await _context.SaveChangesAsync();
        Message = "Invoice created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateCustomerLookup(_context, emptyInvoice.CustomerId);
            return Page();
        }

    }
}

