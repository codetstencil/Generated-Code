using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Artists
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public Artist Artist { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Artist = await _context.Artist
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.ArtistId == id);
        
            if ( Artist == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Artist = await _context.Artist
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.ArtistId == id);
        
            if ( Artist!= null )
            {
                _context.Artist.Remove(Artist);
                await _context.SaveChangesAsync();
            }
        Message = "Artist deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


