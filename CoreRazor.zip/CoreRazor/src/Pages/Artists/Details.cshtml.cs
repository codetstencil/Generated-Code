using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Artists
{
    public class DetailsModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DetailsModel(CoreRazorContext context) => _context = context;
        
        public Artist Artist { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Artist = await _context.Artist
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.ArtistId == id);
        
            if ( Artist == null )
                return NotFound();
            return Page();
        }

    }

}



