using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Artists
{
    public class EditModel : ArtistLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Artist Artist { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Artist = await _context.Artist.FirstOrDefaultAsync(m => m.ArtistId == id);
        
            if (Artist == null)
                return NotFound();
        
            return Page();
        }
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
                return Page();
        
            _context.Attach(Artist).State = EntityState.Modified;
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ArtistExists(Artist.ArtistId))
                    return NotFound();
                else
                    throw;
            }
            return RedirectToPage("./Index");
        }
        private bool ArtistExists(int? id)
        {
            return _context.Artist.Any(e => e.ArtistId == id);
        }
        

    }
}

