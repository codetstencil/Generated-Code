using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class EditModel : InvoiceLineLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public InvoiceLine InvoiceLine { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            InvoiceLine = await _context.InvoiceLine
                .Include(c =>c.Invoice).Include(c =>c.Track)
                .FirstOrDefaultAsync(m => m.InvoiceLineId == id);
        
            if (InvoiceLine == null)
                return NotFound();
        
            // Select current InvoiceId.
            PopulateInvoiceLookup(_context,InvoiceLine.InvoiceLineId);
            // Select current TrackId.
            PopulateTrackLookup(_context,InvoiceLine.InvoiceLineId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var invoicelineToUpdate = await _context.InvoiceLine.FindAsync(id);
        
            if (await TryUpdateModelAsync<InvoiceLine>(
                 invoicelineToUpdate,
                 "invoiceline",
                   s => s.InvoiceId,s => s.TrackId,s => s.UnitPrice,s => s.Quantity))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select InvoiceId if TryUpdateModeAsync fails.
            PopulateInvoiceLookup(_context,invoicelineToUpdate.InvoiceId);
            // Select TrackId if TryUpdateModeAsync fails.
            PopulateTrackLookup(_context,invoicelineToUpdate.TrackId);
            return Page();
        }
        

    }
}

