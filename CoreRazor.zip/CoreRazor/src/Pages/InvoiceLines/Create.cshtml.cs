using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class CreateModel : InvoiceLineLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateInvoiceLookup(_context);
            PopulateTrackLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public InvoiceLine InvoiceLine { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyInvoiceLine = new InvoiceLine();
        
            if (await TryUpdateModelAsync<InvoiceLine>(
                 emptyInvoiceLine,
                 "invoiceline",
                 s => s.InvoiceId,s => s.TrackId,s => s.UnitPrice,s => s.Quantity))
            {
                _context.InvoiceLine.Add(emptyInvoiceLine);
                await _context.SaveChangesAsync();
        Message = "InvoiceLine created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateInvoiceLookup(_context, emptyInvoiceLine.InvoiceId);
            PopulateTrackLookup(_context, emptyInvoiceLine.TrackId);
            return Page();
        }

    }
}

