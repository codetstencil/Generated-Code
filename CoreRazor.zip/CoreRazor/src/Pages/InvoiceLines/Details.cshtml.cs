using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class DetailsModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DetailsModel(CoreRazorContext context) => _context = context;
        
        public InvoiceLine InvoiceLine { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            InvoiceLine = await _context.InvoiceLine
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.InvoiceLineId == id);
        
            if ( InvoiceLine == null )
                return NotFound();
            return Page();
        }

    }

}



