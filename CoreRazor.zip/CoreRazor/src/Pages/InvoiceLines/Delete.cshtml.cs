using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public InvoiceLine InvoiceLine { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            InvoiceLine = await _context.InvoiceLine
              .AsNoTracking().Include(s => s.Invoice).Include(s => s.Track)
              .FirstOrDefaultAsync(m => m.InvoiceLineId == id);
        
            if ( InvoiceLine == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            InvoiceLine = await _context.InvoiceLine
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.InvoiceLineId == id);
        
            if ( InvoiceLine!= null )
            {
                _context.InvoiceLine.Remove(InvoiceLine);
                await _context.SaveChangesAsync();
            }
        Message = "InvoiceLine deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


