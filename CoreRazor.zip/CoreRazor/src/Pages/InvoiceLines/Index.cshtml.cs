using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class IndexModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        [TempData]
        public string Message { get; set; }
        
        public IndexModel(CoreRazorContext context) => _context = context;
        
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public PaginatedList<InvoiceLine> InvoiceLine { get; set; }
        
        public async Task OnGetAsync(string sortOrder, string currentFilter, string searchString, int? pageIndex)
        {
            var invoicelineIq = from s in _context.InvoiceLine select s;
            const int pageSize = 6;
            InvoiceLine = await PaginatedList<InvoiceLine>.CreateAsync(invoicelineIq
               .AsNoTracking()
               .Include(c => c.Invoice)
               .Include(c => c.Track)
               , pageIndex ?? 1, pageSize);
        }
    }
}


