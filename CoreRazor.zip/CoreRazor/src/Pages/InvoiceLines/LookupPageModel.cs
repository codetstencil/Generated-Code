using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.InvoiceLines
{
    public class InvoiceLineLookupPageModel : PageModel
    {
        public SelectList InvoiceSelectList { get; set; }
        
        public  void PopulateInvoiceLookup(CoreRazorContext context, object selectedInvoice = null)
        {
            var invoicesQuery = from q in context.Invoice orderby q.BillingAddress select q;
            InvoiceSelectList = new SelectList(invoicesQuery.AsNoTracking(), "InvoiceId", "BillingAddress", selectedInvoice);
        }
        
        public SelectList TrackSelectList { get; set; }
        
        public  void PopulateTrackLookup(CoreRazorContext context, object selectedTrack = null)
        {
            var tracksQuery = from q in context.Track orderby q.Name select q;
            TrackSelectList = new SelectList(tracksQuery.AsNoTracking(), "TrackId", "Name", selectedTrack);
        }
        

    }
}
