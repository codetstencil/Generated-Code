using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Albums
{
    public class IndexModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        [TempData]
        public string Message { get; set; }
        
        public IndexModel(CoreRazorContext context) => _context = context;
        
        public string CurrentFilter { get; set; }
        public string CurrentSort { get; set; }
        public string ArtistIdSort { get; set; }
        public PaginatedList<Album> Album { get; set; }
        
        public async Task OnGetAsync(string sortOrder, string currentFilter, string searchString, int? pageIndex)
        {
            CurrentSort = sortOrder;
            ArtistIdSort = sortOrder == "artistid_asc" ? "artistid_desc" : "artistid_asc";
        
            var albumIq = from s in _context.Album select s;
        
            switch (sortOrder)
            {
                case "artistid_asc":
                    albumIq = albumIq.OrderBy(s => s.ArtistId);
                    break;
                case "artistid_desc":
                    albumIq = albumIq.OrderByDescending(s => s.ArtistId);
                    break;
            }
            const int pageSize = 6;
            Album = await PaginatedList<Album>.CreateAsync(albumIq
               .AsNoTracking()
               .Include(c => c.Artist)
               , pageIndex ?? 1, pageSize);
        }
    }
}


