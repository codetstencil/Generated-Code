using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Albums
{
    public class EditModel : AlbumLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public Album Album { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            Album = await _context.Album
                .Include(c =>c.Artist)
                .FirstOrDefaultAsync(m => m.AlbumId == id);
        
            if (Album == null)
                return NotFound();
        
            // Select current ArtistId.
            PopulateArtistLookup(_context,Album.AlbumId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var albumToUpdate = await _context.Album.FindAsync(id);
        
            if (await TryUpdateModelAsync<Album>(
                 albumToUpdate,
                 "album",
                   s => s.Title,s => s.ArtistId))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select ArtistId if TryUpdateModeAsync fails.
            PopulateArtistLookup(_context,albumToUpdate.ArtistId);
            return Page();
        }
        

    }
}

