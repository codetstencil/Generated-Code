using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Albums
{
    public class CreateModel : AlbumLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulateArtistLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public Album Album { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyAlbum = new Album();
        
            if (await TryUpdateModelAsync<Album>(
                 emptyAlbum,
                 "album",
                 s => s.Title,s => s.ArtistId))
            {
                _context.Album.Add(emptyAlbum);
                await _context.SaveChangesAsync();
        Message = "Album created successfully.";
                return RedirectToPage("./Index");
            }
            PopulateArtistLookup(_context, emptyAlbum.ArtistId);
            return Page();
        }

    }
}

