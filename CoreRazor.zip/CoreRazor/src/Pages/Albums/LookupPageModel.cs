using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.Albums
{
    public class AlbumLookupPageModel : PageModel
    {
        public SelectList ArtistSelectList { get; set; }
        
        public  void PopulateArtistLookup(CoreRazorContext context, object selectedArtist = null)
        {
            var artistsQuery = from q in context.Artist orderby q.Name select q;
            ArtistSelectList = new SelectList(artistsQuery.AsNoTracking(), "ArtistId", "Name", selectedArtist);
        }
        

    }
}
