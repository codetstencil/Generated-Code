using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.PlaylistTracks
{
    public class EditModel : PlaylistTrackLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public EditModel(CoreRazorContext context) => _context = context;
        
        [BindProperty]
        public PlaylistTrack PlaylistTrack { get; set; }
        
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            PlaylistTrack = await _context.PlaylistTrack
                .Include(c =>c.Playlist).Include(c =>c.Track)
                .FirstOrDefaultAsync(m => m.PlaylistId == id);
        
            if (PlaylistTrack == null)
                return NotFound();
        
            // Select current PlaylistId.
            PopulatePlaylistLookup(_context,PlaylistTrack.PlaylistId);
            // Select current TrackId.
            PopulateTrackLookup(_context,PlaylistTrack.PlaylistId);
            return Page();
        }
        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (!ModelState.IsValid)
                return Page();
        
            var playlisttrackToUpdate = await _context.PlaylistTrack.FindAsync(id);
        
            if (await TryUpdateModelAsync<PlaylistTrack>(
                 playlisttrackToUpdate,
                 "playlisttrack"
                   ))
            {
                await _context.SaveChangesAsync();
                return RedirectToPage("./Index");
            }
            
            // Select PlaylistId if TryUpdateModeAsync fails.
            PopulatePlaylistLookup(_context,playlisttrackToUpdate.PlaylistId);
            // Select TrackId if TryUpdateModeAsync fails.
            PopulateTrackLookup(_context,playlisttrackToUpdate.TrackId);
            return Page();
        }
        

    }
}

