using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.PlaylistTracks
{
    public class CreateModel : PlaylistTrackLookupPageModel
    {
        private readonly CoreRazorContext _context;

        public CreateModel(CoreRazorContext context) => _context = context;
        [TempData]
        public string Message { get; set; }
        public IActionResult OnGet()
        {
            PopulatePlaylistLookup(_context);
            PopulateTrackLookup(_context);
            return Page();
        }
        
        [BindProperty]
        public PlaylistTrack PlaylistTrack { get; set; }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
        
            var emptyPlaylistTrack = new PlaylistTrack();
        
            if (await TryUpdateModelAsync<PlaylistTrack>(
                 emptyPlaylistTrack,
                 "playlisttrack"
                 ))
            {
                _context.PlaylistTrack.Add(emptyPlaylistTrack);
                await _context.SaveChangesAsync();
        Message = "PlaylistTrack created successfully.";
                return RedirectToPage("./Index");
            }
            PopulatePlaylistLookup(_context, emptyPlaylistTrack.PlaylistId);
            PopulateTrackLookup(_context, emptyPlaylistTrack.TrackId);
            return Page();
        }

    }
}

