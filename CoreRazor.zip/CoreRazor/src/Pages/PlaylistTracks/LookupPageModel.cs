using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.PlaylistTracks
{
    public class PlaylistTrackLookupPageModel : PageModel
    {
        public SelectList PlaylistSelectList { get; set; }
        
        public  void PopulatePlaylistLookup(CoreRazorContext context, object selectedPlaylist = null)
        {
            var playlistsQuery = from q in context.Playlist orderby q.Name select q;
            PlaylistSelectList = new SelectList(playlistsQuery.AsNoTracking(), "PlaylistId", "Name", selectedPlaylist);
        }
        
        public SelectList TrackSelectList { get; set; }
        
        public  void PopulateTrackLookup(CoreRazorContext context, object selectedTrack = null)
        {
            var tracksQuery = from q in context.Track orderby q.Name select q;
            TrackSelectList = new SelectList(tracksQuery.AsNoTracking(), "TrackId", "Name", selectedTrack);
        }
        

    }
}
