using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using DolaSoft.CoreRazor.Models;

namespace DolaSoft.CoreRazor.Pages.PlaylistTracks
{
    public class DeleteModel : PageModel
    {
        private readonly CoreRazorContext _context;
        
        public DeleteModel(CoreRazorContext context) => _context = context;
        
        [TempData]
        public string Message { get; set; }
        [BindProperty]
        public PlaylistTrack PlaylistTrack { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            PlaylistTrack = await _context.PlaylistTrack
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.PlaylistId == id);
        
            if ( PlaylistTrack == null )
                return NotFound();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
                return NotFound();
        
            PlaylistTrack = await _context.PlaylistTrack
              .AsNoTracking()
              .FirstOrDefaultAsync(m => m.PlaylistId == id);
        
            if ( PlaylistTrack!= null )
            {
                _context.PlaylistTrack.Remove(PlaylistTrack);
                await _context.SaveChangesAsync();
            }
        Message = "PlaylistTrack deleted succesfully.";
            return RedirectToPage("./Index");
        }

    }

}


