using System;
using System.Collections.Generic;

namespace DolaSoft.CoreRazor.Models
{
    public class Genre 
    {
        public int GenreId { get; set; }
        public string Name { get; set; }
        
        public ICollection<Track> Tracks { get; set; } = new HashSet<Track>();
    }

}

