using System;
using System.Collections.Generic;

namespace DolaSoft.CoreRazor.Models
{
    public class MediaType 
    {
        public int MediaTypeId { get; set; }
        public string Name { get; set; }
        
        public ICollection<Track> Tracks { get; set; } = new HashSet<Track>();
    }

}

