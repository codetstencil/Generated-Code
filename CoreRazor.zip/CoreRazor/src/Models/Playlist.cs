using System;
using System.Collections.Generic;

namespace DolaSoft.CoreRazor.Models
{
    public class Playlist 
    {
        public int PlaylistId { get; set; }
        public string Name { get; set; }
        
        public PlaylistTrack PlaylistTrack { get; set; }
    }

}

