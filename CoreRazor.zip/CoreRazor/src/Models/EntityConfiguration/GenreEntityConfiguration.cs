using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class GenreConfiguration
    {
        public GenreConfiguration(EntityTypeBuilder<Genre> entity)
        {
        entity.ToTable("Genre")
            .HasKey(e => e.GenreId);


        entity.Property(e => e.GenreId)
            .HasColumnName("GenreId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Name)
            .HasColumnName("Name")
            .HasColumnType("string")
            .HasMaxLength(120);
                        

        }
    }
}

