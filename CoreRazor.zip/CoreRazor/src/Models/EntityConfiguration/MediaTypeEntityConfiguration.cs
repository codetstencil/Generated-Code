using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class MediaTypeConfiguration
    {
        public MediaTypeConfiguration(EntityTypeBuilder<MediaType> entity)
        {
        entity.ToTable("MediaType")
            .HasKey(e => e.MediaTypeId);


        entity.Property(e => e.MediaTypeId)
            .HasColumnName("MediaTypeId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Name)
            .HasColumnName("Name")
            .HasColumnType("string")
            .HasMaxLength(120);
                        

        }
    }
}

