using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class InvoiceLineConfiguration
    {
        public InvoiceLineConfiguration(EntityTypeBuilder<InvoiceLine> entity)
        {
        entity.ToTable("InvoiceLine")
            .HasKey(e => e.InvoiceLineId);


        entity.Property(e => e.InvoiceLineId)
            .HasColumnName("InvoiceLineId")
            .HasColumnType("int");
                        

        entity.HasIndex(e => e.InvoiceId)
            .HasName("IFK_InvoiceLineInvoiceId");

        entity.Property(e => e.InvoiceId)
            .HasColumnName("InvoiceId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Invoice)
            .WithMany(p => p.InvoiceLines)
            .HasForeignKey(d => d.InvoiceId)
            .HasConstraintName("FK_InvoiceLineInvoiceId");            

        entity.HasIndex(e => e.TrackId)
            .HasName("IFK_InvoiceLineTrackId");

        entity.Property(e => e.TrackId)
            .HasColumnName("TrackId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Track)
            .WithMany(p => p.InvoiceLines)
            .HasForeignKey(d => d.TrackId)
            .HasConstraintName("FK_InvoiceLineTrackId");            

        entity.Property(e => e.UnitPrice)
            .HasColumnName("UnitPrice")
            .HasColumnType("decimal");
                        

        entity.Property(e => e.Quantity)
            .HasColumnName("Quantity")
            .HasColumnType("int");
                        

        }
    }
}

