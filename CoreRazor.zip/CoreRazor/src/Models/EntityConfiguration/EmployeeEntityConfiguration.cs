using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class EmployeeConfiguration
    {
        public EmployeeConfiguration(EntityTypeBuilder<Employee> entity)
        {
        entity.ToTable("Employee")
            .HasKey(e => e.EmployeeId);


        entity.Property(e => e.EmployeeId)
            .HasColumnName("EmployeeId")
            .HasColumnType("int");
                        

        entity.Property(e => e.LastName)
            .HasColumnName("LastName")
            .HasColumnType("string")
            .HasMaxLength(20);
                        

        entity.Property(e => e.FirstName)
            .HasColumnName("FirstName")
            .HasColumnType("string")
            .HasMaxLength(20);
                        

        entity.Property(e => e.Title)
            .HasColumnName("Title")
            .HasColumnType("string")
            .HasMaxLength(30);
                        

        entity.HasIndex(e => e.ReportsTo)
            .HasName("IFK_EmployeeReportsTo");

        entity.Property(e => e.ReportsTo)
            .HasColumnName("ReportsTo")
            .HasColumnType("int");
            
        entity.HasOne(d => d.ReportsToNavigation)
            .WithMany(p => p.Employees)
            .HasForeignKey(d => d.ReportsTo)
            .HasConstraintName("FK_EmployeeReportsTo");            

        entity.Property(e => e.BirthDate)
            .HasColumnName("BirthDate")
            .HasColumnType("DateTime");
                        

        entity.Property(e => e.HireDate)
            .HasColumnName("HireDate")
            .HasColumnType("DateTime");
                        

        entity.Property(e => e.Address)
            .HasColumnName("Address")
            .HasColumnType("string")
            .HasMaxLength(70);
                        

        entity.Property(e => e.City)
            .HasColumnName("City")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.State)
            .HasColumnName("State")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.Country)
            .HasColumnName("Country")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.PostalCode)
            .HasColumnName("PostalCode")
            .HasColumnType("string")
            .HasMaxLength(10);
                        

        entity.Property(e => e.Phone)
            .HasColumnName("Phone")
            .HasColumnType("string")
            .HasMaxLength(24);
                        

        entity.Property(e => e.Fax)
            .HasColumnName("Fax")
            .HasColumnType("string")
            .HasMaxLength(24);
                        

        entity.Property(e => e.Email)
            .HasColumnName("Email")
            .HasColumnType("string")
            .HasMaxLength(60);
                        

        }
    }
}

