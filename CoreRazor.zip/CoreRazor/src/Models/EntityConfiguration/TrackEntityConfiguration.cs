using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class TrackConfiguration
    {
        public TrackConfiguration(EntityTypeBuilder<Track> entity)
        {
        entity.ToTable("Track")
            .HasKey(e => e.TrackId);


        entity.Property(e => e.TrackId)
            .HasColumnName("TrackId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Name)
            .HasColumnName("Name")
            .HasColumnType("string")
            .HasMaxLength(200);
                        

        entity.HasIndex(e => e.AlbumId)
            .HasName("IFK_TrackAlbumId");

        entity.Property(e => e.AlbumId)
            .HasColumnName("AlbumId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Album)
            .WithMany(p => p.Tracks)
            .HasForeignKey(d => d.AlbumId)
            .HasConstraintName("FK_TrackAlbumId");            

        entity.HasIndex(e => e.MediaTypeId)
            .HasName("IFK_TrackMediaTypeId");

        entity.Property(e => e.MediaTypeId)
            .HasColumnName("MediaTypeId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.MediaType)
            .WithMany(p => p.Tracks)
            .HasForeignKey(d => d.MediaTypeId)
            .HasConstraintName("FK_TrackMediaTypeId");            

        entity.HasIndex(e => e.GenreId)
            .HasName("IFK_TrackGenreId");

        entity.Property(e => e.GenreId)
            .HasColumnName("GenreId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Genre)
            .WithMany(p => p.Tracks)
            .HasForeignKey(d => d.GenreId)
            .HasConstraintName("FK_TrackGenreId");            

        entity.Property(e => e.Composer)
            .HasColumnName("Composer")
            .HasColumnType("string")
            .HasMaxLength(220);
                        

        entity.Property(e => e.Milliseconds)
            .HasColumnName("Milliseconds")
            .HasColumnType("int");
                        

        entity.Property(e => e.Bytes)
            .HasColumnName("Bytes")
            .HasColumnType("int");
                        

        entity.Property(e => e.UnitPrice)
            .HasColumnName("UnitPrice")
            .HasColumnType("decimal");
                        

        }
    }
}

