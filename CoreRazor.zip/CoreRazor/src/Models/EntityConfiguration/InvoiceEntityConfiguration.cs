using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class InvoiceConfiguration
    {
        public InvoiceConfiguration(EntityTypeBuilder<Invoice> entity)
        {
        entity.ToTable("Invoice")
            .HasKey(e => e.InvoiceId);


        entity.Property(e => e.InvoiceId)
            .HasColumnName("InvoiceId")
            .HasColumnType("int");
                        

        entity.HasIndex(e => e.CustomerId)
            .HasName("IFK_InvoiceCustomerId");

        entity.Property(e => e.CustomerId)
            .HasColumnName("CustomerId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Customer)
            .WithMany(p => p.Invoices)
            .HasForeignKey(d => d.CustomerId)
            .HasConstraintName("FK_InvoiceCustomerId");            

        entity.Property(e => e.InvoiceDate)
            .HasColumnName("InvoiceDate")
            .HasColumnType("DateTime");
                        

        entity.Property(e => e.BillingAddress)
            .HasColumnName("BillingAddress")
            .HasColumnType("string")
            .HasMaxLength(70);
                        

        entity.Property(e => e.BillingCity)
            .HasColumnName("BillingCity")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.BillingState)
            .HasColumnName("BillingState")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.BillingCountry)
            .HasColumnName("BillingCountry")
            .HasColumnType("string")
            .HasMaxLength(40);
                        

        entity.Property(e => e.BillingPostalCode)
            .HasColumnName("BillingPostalCode")
            .HasColumnType("string")
            .HasMaxLength(10);
                        

        entity.Property(e => e.Total)
            .HasColumnName("Total")
            .HasColumnType("decimal");
                        

        }
    }
}

