using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class ArtistConfiguration
    {
        public ArtistConfiguration(EntityTypeBuilder<Artist> entity)
        {
        entity.ToTable("Artist")
            .HasKey(e => e.ArtistId);


        entity.Property(e => e.ArtistId)
            .HasColumnName("ArtistId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Name)
            .HasColumnName("Name")
            .HasColumnType("string")
            .HasMaxLength(120);
                        

        }
    }
}

