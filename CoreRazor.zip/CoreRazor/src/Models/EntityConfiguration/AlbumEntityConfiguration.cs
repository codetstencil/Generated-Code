using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class AlbumConfiguration
    {
        public AlbumConfiguration(EntityTypeBuilder<Album> entity)
        {
        entity.ToTable("Album")
            .HasKey(e => e.AlbumId);


        entity.Property(e => e.AlbumId)
            .HasColumnName("AlbumId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Title)
            .HasColumnName("Title")
            .HasColumnType("string")
            .HasMaxLength(160);
                        

        entity.HasIndex(e => e.ArtistId)
            .HasName("IFK_AlbumArtistId");

        entity.Property(e => e.ArtistId)
            .HasColumnName("ArtistId")
            .HasColumnType("int");
            
        entity.HasOne(d => d.Artist)
            .WithMany(p => p.Albums)
            .HasForeignKey(d => d.ArtistId)
            .HasConstraintName("FK_AlbumArtistId");            

        }
    }
}

