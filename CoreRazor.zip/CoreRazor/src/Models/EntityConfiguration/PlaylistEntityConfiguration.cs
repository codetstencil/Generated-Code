using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class PlaylistConfiguration
    {
        public PlaylistConfiguration(EntityTypeBuilder<Playlist> entity)
        {
        entity.ToTable("Playlist")
            .HasKey(e => e.PlaylistId);


        entity.Property(e => e.PlaylistId)
            .HasColumnName("PlaylistId")
            .HasColumnType("int");
                        

        entity.Property(e => e.Name)
            .HasColumnName("Name")
            .HasColumnType("string")
            .HasMaxLength(120);
                        

        }
    }
}

