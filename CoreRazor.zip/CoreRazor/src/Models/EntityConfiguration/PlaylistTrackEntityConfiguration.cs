using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DolaSoft.CoreRazor.Models
{
    public class PlaylistTrackConfiguration
    {
        public PlaylistTrackConfiguration(EntityTypeBuilder<PlaylistTrack> entity)
        {
        entity.ToTable("PlaylistTrack")
            .HasKey(e => new { e.PlaylistId,e.TrackId});


        entity.Property(e => e.PlaylistId)
            .HasColumnName("PlaylistId")
            .HasColumnType("int");
                        
        // OneToOne (Playlist<->PlaylistTrack)
        entity.HasOne(p => p.Playlist)
            .WithOne(i => i.PlaylistTrack)
            .HasForeignKey<PlaylistTrack>(b => b.PlaylistId)
            .HasConstraintName("FK_PlaylistTrackPlaylistId");

        entity.Property(e => e.TrackId)
            .HasColumnName("TrackId")
            .HasColumnType("int");
                        
        // OneToOne (Track<->PlaylistTrack)
        entity.HasOne(p => p.Track)
            .WithOne(i => i.PlaylistTrack)
            .HasForeignKey<PlaylistTrack>(b => b.PlaylistId)
            .HasConstraintName("FK_PlaylistTrackTrackId");

        }
    }
}

